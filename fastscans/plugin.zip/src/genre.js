load('config.js');

function execute() {
    let response = fetch(BASE_URL);
    if (!response.ok) {
        return Response.error("Không thể tải trang chính!");
    }

    let el = response.html().select('.dropdown-menu li a');
    if (!el) {
        return Response.error("Không tìm thấy menu dropdown!");
    }

    let data = [];
    for (var i = 9; i < 13; i++) {
        var e = el.get(i);
        if (e) {
            data.push({
                title: e.text(),
                input: e.attr('href').split('=').pop(),
                script: 'search.js'
            });
        }
    }

    return Response.success(data);
}