load('config.js');
function execute(url, page) {
    if (!page) page = '1';
    let response = fetch(`${BASE_API}/portal/api/client/comicapp/paging`, {
        method: 'GET',
        queries: {
            'PageNumber': page,
            'PageSize': '24',
            "SearchTerm": url,
            'SortColumn': 'title',
            'SortDirection': 'desc',
            "region": "vi"
        }
    });

    if (response.ok) {
        let json = response.json();
        if (json && json.data) {  // Check if 'data' exists in response
            let books = [];

            json.data.forEach(item => {
                books.push({
                    name: item.title,
                    link: BASE_URL + '/truyen-tranh/' + item.friendlyName,
                    cover: item.cdnThumbnailUrl,
                    description: item.tags + ', ' + item.lastCollectionTitle,
                });
            });

            var next = json.data.length === 0 ? null : (parseInt(page) + 1).toString();
            return Response.success(books, next);
        }
    }

    return null;
}