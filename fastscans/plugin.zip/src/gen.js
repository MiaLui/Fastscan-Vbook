load('config.js');

function execute(url, page) {
    // Nếu không có tham số page, mặc định giá trị là '1'
    if (!page) page = '1';

    // Gọi API để lấy dữ liệu
    let response = fetch(`${BASE_API}/portal/api/client/comicapp/paging`, {
        method: 'GET',
        queries: {
            'PageNumber': page,           // Số trang
            'PageSize': '24',             // Kích thước trang (số lượng mục trong một trang)
            'SortColumn': url,            // Sắp xếp theo cột truyền vào từ tham số
            'SortDirection': 'desc',      // Hướng sắp xếp (giảm dần)
            "region": "vi"                // Vùng dữ liệu (ở đây là Việt Nam)
        }
    });

    if (!response.ok) {
        return Response.error("Không thể lấy dữ liệu từ API!");
    }

    let json = response.json();
    if (json && json.data) {
        let books = [];

        json.data.forEach(item => {
            if (item && item.title && item.friendlyName && item.cdnThumbnailUrl) {
                books.push({
                    name: item.title,
                    link: BASE_URL + '/truyen-tranh/' + item.friendlyName,
                    cover: item.cdnThumbnailUrl,
                    description: item.tags + ', ' + item.lastCollectionTitle
                });
            }
        });

        let next = json.data.length === 0 ? null : (parseInt(page) + 1).toString();

        return Response.success(books, next);
    }

    return Response.error("Lỗi dữ liệu không hợp lệ!");
}