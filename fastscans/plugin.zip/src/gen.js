load('config.js');

function execute(url, page) {
    // Nếu không có tham số page, mặc định giá trị là '1'
    if (!page) page = '1';

    // Gọi API để lấy dữ liệu
    let response = fetch(`${BASE_API}/portal/api/client/comicapp/paging`, {
        method: 'GET',
        queries: {
            'PageNumber': page,           // Số trang
            'PageSize': '24',             // Kích thước trang (số lượng mục trong một trang)
            'SortColumn': url,            // Sắp xếp theo cột truyền vào từ tham số
            'SortDirection': 'desc',      // Hướng sắp xếp (giảm dần)
            "region": "vi"                // Vùng dữ liệu (ở đây là Việt Nam)
        }
    });

    // Kiểm tra xem phản hồi có thành công không
    if (response.ok) {
        // Lấy dữ liệu JSON từ phản hồi
        let json = response.json();
        
        // Kiểm tra xem dữ liệu JSON có tồn tại và chứa trường data không
        if (json && json.data) {
            let books = []; // Mảng để chứa danh sách sách/truyện

            // Lặp qua từng phần tử trong dữ liệu để tạo đối tượng sách
            json.data.forEach(item => {
                books.push({
                    name: item.title,                                       // Tên truyện
                    link: BASE_URL + '/truyen-tranh/' + item.friendlyName,  // Link đến truyện
                    cover: item.cdnThumbnailUrl,                            // URL ảnh bìa
                    description: item.tags + ', ' + item.lastCollectionTitle // Mô tả truyện (tags và tên bộ sưu tập cuối cùng)
                });
            });

            // Kiểm tra nếu không có thêm dữ liệu, không trả về trang tiếp theo
            let next = json.data.length === 0 ? null : (parseInt(page) + 1).toString();

            // Trả về phản hồi thành công với danh sách sách và trang tiếp theo
            return Response.success(books, next);
        }
    }

    // Nếu phản hồi không thành công hoặc có lỗi, trả về null
    return null;
}