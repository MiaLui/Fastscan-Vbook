let BASE_URL = "https://fastscans5.net/";
let BASE_API = `https://api.fastscans3.net/`;
let BASE_IMAGE = "https://s1.fstscnmw.org/";
const decodeMap = {
    1: "a",
    2: "b",
    3: "c",
    4: "d",
    5: "e",
    6: "f",
    7: "g",
    8: "h",
    9: "i",
    0: "j",
    q: "k",
    w: "l",
    e: "m",
    r: "n",
    t: "o",
    y: "p",
    u: "q",
    i: "r",
    o: "s",
    p: "t",
    a: "u",
    s: "v",
    d: "w",
    f: "x",
    g: "y",
    h: "z",
    z: "0",
    x: "1",
    c: "2",
    v: "3",
    b: "4",
    n: "5",
    m: "6",
    l: "7",
    k: "8",
    j: "9",
};

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}