import { BASE_URL } from "./config";

function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "updatedOnUtc", script: "gen.js" },
        { title: "Phổ Biến", input: "views", script: "gen.js" },
        {title: "Tên miền", input: BASE_URL, script: "config.js"}
    ]);
}