load('config.js')

function execute(url) {
    const doc = fetch(url).html()
    return Response.success({
        name: doc.select("h1").text() || "Unknown",
        cover: doc.select(".trailer-box img").first() ? doc.select(".trailer-box img").first().attr("src") : "",
        author: doc.select("p:contains(Tác giả) b").first() ? doc.select("p:contains(Tác giả) b").first().text() : "Unknown",
        description: doc.select(".col-lg-6 .trailer-content p").last() ? doc.select(".col-lg-6 .trailer-content p").last().text() : "No description",
        detail: doc.select(".col-lg-3 .trailer-content").html() ? doc.select(".col-lg-3 .trailer-content").html().replace(/\n/g, '<br>') : "No details",
        ongoing: doc.select(".trailer-content").html().indexOf("Đang tiến hành") != -1,
        host: BASE_URL
    });
}