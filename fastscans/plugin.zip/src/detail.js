load('config.js');

function execute(url) {
    const doc = fetch(url).html();
    if (!doc) {
        return Response.error("Không thể tải trang HTML!");
    }

    const name = doc.select("h1").text();
    const cover = doc.select(".trailer-box img").first();
    const author = doc.select("p:contains(Tác giả) b").first();
    const description = doc.select(".col-lg-6 .trailer-content p").last();
    const detail = doc.select(".col-lg-3 .trailer-content").html();

    if (!name || !cover || !author || !description || !detail) {
        return Response.error("Lỗi không tìm thấy thông tin cần thiết!");
    }

    return Response.success({
        name: name,
        cover: cover.attr("src"),
        author: author.text(),
        description: description.text(),
        detail: detail.replace(/\n/g, '<br>'),
        ongoing: detail.indexOf("Đang tiến hành") !== -1,
        host: BASE_URL
    });
}